import React from "react";

function Like() {
   return (
      <div>Like</div>
   )
};

export default Like;