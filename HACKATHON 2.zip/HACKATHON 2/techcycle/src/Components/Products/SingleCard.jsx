import React from "react";

function SingleCard() {
   return (
      <div>SingleCard</div>
   )
};

export default SingleCard;