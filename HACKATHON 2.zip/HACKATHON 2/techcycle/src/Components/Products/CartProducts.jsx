import React from "react";

function CartProducts() {
   return (
      <div>CartProducts</div>
   )
};

export default CartProducts;