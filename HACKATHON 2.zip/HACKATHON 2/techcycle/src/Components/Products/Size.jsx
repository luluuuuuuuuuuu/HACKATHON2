import React from "react";

function Size() {
   return (
      <div>Size</div>
   )
};

export default Size;