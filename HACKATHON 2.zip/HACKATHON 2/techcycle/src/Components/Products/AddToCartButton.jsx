import React from "react";

function AddToCartButton() {
   return (
      <div>AddToCartButton</div>
   )
};

export default AddToCartButton;